cls
Write-Host "===================================" -ForegroundColor Cyan
Write-Host "🛡️ NO-STEALER PIPELINE LAUNCHER" -ForegroundColor Green
Write-Host "===================================" -ForegroundColor Cyan

$ErrorActionPreference = "Stop"

$Scripts = @(
    "telemetry.ps1",
    "static.ps1",
    "analyze.ps1"
)

foreach ($script in $Scripts)
{
    Write-Host "`n🚀 Running $script ..." -ForegroundColor Yellow

    if (!(Test-Path $script)) {
        Write-Host "❌ $script bulunamadı!" -ForegroundColor Red
        exit
    }

    try {
        powershell -ExecutionPolicy Bypass -File $script
        Write-Host "✅ $script tamamlandı." -ForegroundColor Green
    }
    catch {
        Write-Host "🔥 ERROR in $script" -ForegroundColor Red
        Write-Host $_
        exit
    }
}

Write-Host "`n===================================" -ForegroundColor Cyan
Write-Host "🎯 NO-STEALER ANALYSIS COMPLETED" -ForegroundColor Green
Write-Host "📄 Output file: NO_STEALER_RESULT.json"
Write-Host "===================================" -ForegroundColor Cyan

