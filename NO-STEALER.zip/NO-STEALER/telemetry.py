import psutil
import json

all_processes = []

for proc in psutil.process_iter():
    try:
       data = {}
       
       data["path"]


