cls
Write-Host "🛡️ NO-STEALER CORE ANALYZER w/ C2-INTEL" -ForegroundColor Cyan

# ----------------------------
# LOAD FILES
# ----------------------------

$IOC = Get-Content ".\c2.txt"

$StealerDB = @()
Get-ChildItem ".\stealers" -Filter "*.json" | ForEach-Object {
    $StealerDB += (Get-Content $_.FullName -Raw | ConvertFrom-Json)
}

$Live = Get-Content ".\live_behavior.json" -Raw | ConvertFrom-Json
$Static = Get-Content ".\static_scan.json" -Raw | ConvertFrom-Json


# ----------------------------
# HELPER FUNCTIONS
# ----------------------------

function Match-C2IOC($Network){

    $hits = @()

    foreach($conn in $Network){
        foreach($ioc in $IOC){
            if($conn.remote -match [regex]::Escape($ioc)){
                $hits += $ioc
            }
        }
    }

    return $hits
}


function Compare-Similarity($Process,$Stealer){

    $Score = 0
    $Matches = @()

    foreach($dom in $Stealer.behaviors.network_domains){
        if($Process.network -match $dom){
            $Score += 5
            $Matches += $dom
        }
    }

    foreach($dll in $Stealer.behaviors.dlls){
        if($Process.dlls -contains $dll){
            $Score += 3
            $Matches += $dll
        }
    }

    foreach($str in $Stealer.static_strings){
        if($Process.static.detected -contains $str){
            $Score += 4
            $Matches += $str
        }
    }

    return @{Score=$Score;Matches=$Matches}
}


function Get-RiskScore($Proc, $C2Matches){

    $Risk = 0

    # ---- IOC HIT BONUS ----
    if($C2Matches.Count -gt 0){
        $Risk += 30
    }

    if($Proc.network -match "telegram|discord"){
        $Risk += 15
    }

    if($Proc.files -match "Login Data|INetCookies"){
        $Risk += 20
    }

    if($Proc.static.hit_count -gt 0){
        $Risk += ($Proc.static.hit_count * 10)
    }

    if($Proc.cmd -match "-enc|powershell|cmd"){
        $Risk += 10
    }

    return [Math]::Min($Risk,100)
}


# ----------------------------
# CORE ANALYSIS LOOP
# ----------------------------

$Results = @()

foreach($P in $Live){

    $staticHit = $Static | Where-Object {$_.path -eq $P.path}
    $P | Add-Member -Name "static" -Value $staticHit -MemberType NoteProperty -Force

    # ---- C2 IOC CHECK ----
    $c2Matches = Match-C2IOC $P.network

    $BestMatchScore = 0
    $BestFamily = ""
    $BestPatterns = @()

    foreach($S in $StealerDB){

        $sim = Compare-Similarity $P $S

        if($sim.Score -gt $BestMatchScore){
            $BestMatchScore = $sim.Score
            $BestFamily = $S.family
            $BestPatterns = $sim.Matches
        }
    }

    $risk = Get-RiskScore $P $c2Matches
    $final = [Math]::Round(($BestMatchScore*0.6)+($risk*0.4),2)

    $verdict = switch ($final) {
        {$_ -ge 65 -or $c2Matches.Count -gt 0} {"🛑 STEALER"}
        {$_ -ge 40} {"❗ HIGH RISK"}
        {$_ -ge 20} {"⚠️ SUSPICIOUS"}
        default {"✅ CLEAN"}
    }

    $Results += [PSCustomObject]@{
        process  = $P.path
        cmdline = $P.cmd
        family_guess = $BestFamily
        similarity_score = $BestMatchScore
        risk_score = $risk
        final_score = $final
        c2_hits = ($c2Matches -join ", ")
        matched_patterns = ($BestPatterns -join ", ")
        verdict = $verdict
    }

}

# ----------------------------
# SAVE OUTPUT
# ----------------------------

$outFile = ".\NO_STEALER_RESULT.json"
$Results | ConvertTo-Json -Depth 6 | Out-File $outFile -Encoding utf8

Write-Host ""
Write-Host "✅ ANALYSIS COMPLETED" -ForegroundColor Green
Write-Host "📄 Output: $outFile" -ForegroundColor Yellow

