Write-Host "`n🔍 Python dosyasını analiz etmek için yol girin:" -ForegroundColor Cyan
$file = Read-Host "📄 Dosya Yolu (örnek: C:\Users\Enes\Desktop\spy.py)"

$bad = @(
    "requests.post","requests.get","httpx.post","http.client","urllib.request",
    "os.getenv","os.system","subprocess.call","subprocess.Popen","socket.socket",
    "base64.b64decode","base64.b64encode","binascii.a2b_base64","binascii.b2a_base64",
    "eval","exec","compile","marshal.loads","pickle.loads","builtins.__import__",
    "getpass.getpass","input","open(","write(","read(","shutil.copyfile",
    "zipfile.ZipFile","tempfile.gettempdir","tempfile.NamedTemporaryFile","os.remove",
    "threading.Thread","multiprocessing.Process","platform.system","platform.node",
    "ctypes.windll","ctypes.cdll","ctypes.WinDLL","win32api","win32gui","win32con",
    "win32clipboard","winreg","win32com.client","WTSQuerySessionInformation",
    "GetAsyncKeyState","SetWindowsHookEx","GetForegroundWindow","FindWindow","ShowWindow",
    "pyautogui.screenshot","pyautogui.typewrite","pynput.keyboard","pynput.mouse",
    "webbrowser.open","re.compile","email.mime","smtplib.SMTP","ftplib.FTP","dns.resolver",
    "getmac.get_mac_address","requests.put","requests.delete","send_keys",
    "clipboard.paste","clipboard.copy",

    "discord.com/api","discordapp.com/api","token=","Authorization:","webhook.site",
    "webhook","run_payload","inject","reverse_shell","backconnect","bindshell",

    "startup_folder","add_to_startup","schtasks","taskkill","tasklist",
    "WMIC PROCESS CALL","powershell -enc","cmd.exe","cmd /c",
    "curl","wget","whoami","netstat","ipconfig"
)

if (-not (Test-Path $file)) {
    Write-Host "❌ Dosya bulunamadı: $file" -ForegroundColor Red
    exit
}

$content = Get-Content $file -Raw
$found = @()

foreach ($b in $bad) {
    if ($content -match [regex]::Escape($b)) {
        $found += $b
    }
}

# ---------- Risk Score ----------
$total_bad = $bad.Count
$hit_count = $found.Count
$risk_percent = [math]::Min([math]::Round(($hit_count / $total_bad) * 100,2),99)

# ---------- Result JSON ----------
$result = @{
    target_file   = $file
    analyzed_at   = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    total_strings = $total_bad
    hit_count     = $hit_count
    detected      = $found
    risk_percent  = $risk_percent
}

$outputPath = "$env:TEMP\static_analysis_result.json"

$result | ConvertTo-Json -Depth 4 | Out-File $outputPath -Encoding utf8

# ---------- OUTPUT ----------
Write-Host "`n======================" -ForegroundColor DarkGray
Write-Host "📊 Analiz Sonucu:" -ForegroundColor Magenta
Write-Host "----------------------" -ForegroundColor DarkGray

if ($hit_count -eq 0) {
    Write-Host "✅ Hiçbir şüpheli string bulunamadı." -ForegroundColor Green
}
else {
    Write-Host "⚠️ Şüpheli stringler bulundu ($hit_count adet):" -ForegroundColor Yellow

    $found | ForEach-Object {
        Write-Host " - $_"
    }

    Write-Host "`n⚠️ Tahmini Risk Oranı: %$risk_percent" -ForegroundColor Red
}

Write-Host "`n🧾 JSON raporu kaydedildi:`n$outputPath" -ForegroundColor Cyan
Write-Host "======================`n" -ForegroundColor DarkGray

