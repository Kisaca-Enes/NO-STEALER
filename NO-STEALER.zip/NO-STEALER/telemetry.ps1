# -------------------------
# NO STEALER BEHAVIOR DUMP
# -------------------------

$results = @()

# Process commandline almak için WMI cache
$wmiProcs = Get-CimInstance Win32_Process

Get-Process | ForEach-Object {
    $p = $_

    try {

        $item = [ordered]@{}

        # ---- PATH / CMD ----
        $item.path = $p.Path

        $cmd = ($wmiProcs | Where-Object { $_.ProcessId -eq $p.Id }).CommandLine
        $item.cmd = if ($cmd) { $cmd } else { "" }

        # ---- PID + PPID ----
        $item.pid = $p.Id
        $item.ppid = ($wmiProcs | Where-Object { $_.ProcessId -eq $p.Id }).ParentProcessId

        # ---- PARENT ----
        try {
            $parent = Get-Process -Id $item.ppid -ErrorAction Stop
            $item.parent_name = $parent.ProcessName
            $item.parent_path = $parent.Path
        }
        catch {
            $item.parent_name = $null
            $item.parent_path = $null
        }

        # ---- CHILD PROCESSES ----
        $item.children = @()

        $childs = $wmiProcs | Where-Object { $_.ParentProcessId -eq $p.Id }
        foreach ($c in $childs) {
            $item.children += @{
                name = $c.Name
                path = $c.ExecutablePath
            }
        }

        # ---- NETWORK ----
        $item.network = @()

        try {
            Get-NetTCPConnection -OwningProcess $p.Id -ErrorAction Stop |
            ForEach-Object {
                $item.network += @{
                    local  = "$($_.LocalAddress):$($_.LocalPort)"
                    remote = "$($_.RemoteAddress):$($_.RemotePort)"
                    status = $_.State
                }
            }
        }
        catch {}

        # ---- DLL MODULES ----
        $item.dlls = @()

        try {
            $p.Modules | ForEach-Object {
                $item.dlls += $_.FileName
            }
        }
        catch {}

        # ---- OPEN FILES ----
        # (PS/Windows native olarak tam erişim yok, classict handle listelenemiyor)
        $item.files = @()
        $item.files += "[!] Windows API limitation - ProcMon needed for real file audit"

        $results += $item

    }
    catch {}
}

# ---- SAVE JSON ----
$outputPath = "$env:TEMP\no_stealer_dump.json"
$results | ConvertTo-Json -Depth 6 | Out-File $outputPath -Encoding UTF8

Write-Host ""
Write-Host "[+] NO-STEALER Behavior Snapshot Completed"
Write-Host "[+] JSON saved to:"
Write-Host "    $outputPath"

